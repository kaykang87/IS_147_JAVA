/* Kyong Kang
   kyongk1@umbc.edu
 */

package com.company;

public class Main extends InterfaceInheritance
{
    Main()
    {
        super();
    }
}
