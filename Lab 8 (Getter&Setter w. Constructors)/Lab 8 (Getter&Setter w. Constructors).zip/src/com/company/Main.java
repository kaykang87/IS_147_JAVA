/* Kyong Kang
    kyongk1@umbc.edu
 */

package com.company;

public class Main
{
    public static void main(String[] args)
    {
        Area area = new Area(5,5);
        System.out.println(area.getAreaofTriangle());
        System.out.println(area.getPerimeter());
    }
}

